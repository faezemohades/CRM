import { BrowserRouter, Route, Routes} from "react-router-dom";
import Layout from './Components/common/Layout';
import './style/Styles.css';
import './style/Responsive.css';
import Login from "./Pages/Login";
import Content from "./Pages/Content";
import Bill from "./Pages/Bill";
import TraficReport from "./Pages/TraficReport";
import Profile from "./Pages/Profile";
import { createContext, useEffect, useState } from "react";
 import PrivateRoute from "./PrivateRoute"
import Notfound from "./Components/Notfound";
import { QueryClient, QueryClientProvider } from 'react-query';
import ChangePassword from "./Pages/ChangePassword";

export const ThemeContext = createContext(null);

const App = () => {

    const client = new QueryClient({
        defaultOptions: {
            queries: {refetchOnWindowFocus:false}
        }
    });

    const [theme, setTheme] = useState('light');

    const toggleTheme = () => {
        setTheme((curr) => (curr === 'light' ? "dark" : "light"))
    }

    useEffect(() => {
        localStorage.setItem('theme', theme);
    }, [theme]);

     const savedTheme = localStorage.getItem('theme');
    useEffect(() => {
        if (savedTheme) {
            setTheme(savedTheme);
        }
    }, []);

    // Save theme to local storage whenever it changes
    useEffect(() => {
        if (theme === 'dark') {
            document.body.classList.add('dark-theme');
        } else {
            document.body.classList.remove('dark-theme');
        }
    }, [theme]);

    return (
        <QueryClientProvider client={client}>
             <BrowserRouter>
                  <ThemeContext.Provider value={{ theme, toggleTheme }}>
                    <div id={theme}>
                        <Routes>
                            <Route element={<Login />} path="/login" />

                             <Route element={<Notfound />} path="*" />
                            <Route element={<PrivateRoute />}>
                                <Route path="/" element={<Layout />}>
                                <Route exact path="/" element={<Profile />} />
                                <Route  path="/content" element={<Content />} />
                                <Route  path="/bill" element={<Bill />} />
                                <Route path="/trafic" element={<TraficReport />} />
                                <Route path="/ChangePassword" element={<ChangePassword />} />

                                </Route>
                            </Route>
                      </Routes>
                    </div>
                  </ThemeContext.Provider>
             </BrowserRouter>
        </QueryClientProvider>

      )
}

export default App