﻿import { useContext, useState } from 'react';
import { ThemeContext } from '../App';
import { Table } from 'reactstrap';
import Paginations from './Paginations';

const ITEMS_PER_PAGE = 20;

const ReusableTable = ({ data1, headers }) => {

    const { theme } = useContext(ThemeContext);
    const [currentPage, setCurrentPage] = useState(1);

    // Calculate the total number of pages based on the data length and items per page
    const totalPages = Math.ceil(data1?.length / ITEMS_PER_PAGE);

    // Calculate the starting and ending indices of the current page's data
    const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
    const endIndex = startIndex + ITEMS_PER_PAGE;

    // Get the current page's data
    const currentPageData = data1?.slice(startIndex, endIndex);

    // Handle page change
    const handlePageChange = (pageNumber) => {
        setCurrentPage(pageNumber);
    };

    const showPagination = data1?.length > ITEMS_PER_PAGE;
    if (!data1 || data1?.length === 0) return <div className="align-self-center mt-5 bold-text" style={{ color: "#FB9678" }}> <p>رکوردی برای نمایش وجود ندارد.</p></div>

    return (
        <>
            <div className="table-container rounded mt-4" style={{ overflowX: "auto", width: "100%" }}>
                {currentPageData ?
                    <Table size="sm" className={`mt-1  ${theme === "dark" ? "dark-table" : ""}`}>
                        <thead>
                            <tr className={theme === "dark" ? "text-light" : ""}>
                                {headers.map((header) => (
                                    <th key={header.id}>{header.label}</th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {currentPageData?.map((item, index) => (
                                <tr key={item.id} style={{ backgroundColor: index % 2 === 0 ? 'rgba(0,203,215,0.10)' : '' }}>
                                    {Object.keys(item).map((key) => (
                                        <td key={key}>{item[key]}</td>
                                    ))}
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                    : ""}
                {/*pagination*/}
                {showPagination && (
                    <div className="d-flex justify-content-end mx-1">
                        <Paginations totalPages={totalPages} handlePageChange={handlePageChange} currentPage={currentPage} />
                    </div>)}
            </div>
        </>
    )
}

export default ReusableTable;