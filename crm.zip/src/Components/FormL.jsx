﻿import React, { useEffect, useState } from "react";
import { Form } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { login } from '../store/authSlice';
import { API_BASE } from "../data/apiConfig";
import axios from "axios";
 
const FormL = () => {

    const { isLoogedIn } = useSelector((state) => state.auth)
    const [message, setMessage] = useState("");
    const navigate = useNavigate();
    const [msg, setMsg] = useState();
    const dispatch = useDispatch();

    useEffect(() => {
        if (isLoogedIn) {
            navigate("/");
        }
        else {
            navigate("/login");
        }
    }, [isLoogedIn]);

  const handleFormSubmit = async (event) => {
    event.preventDefault();
    const username = event.target.username.value;
    const password = event.target.password.value;
    try {
        if (!username && !password) {
            setMessage("هیچ مقداری درج نشده است.");
        } else {
            const apiUrl = `${API_BASE}/login`;

            const response = await fetch(apiUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Cache-Control': 'no-cache',
                    'Pragma': 'no-cache',
                },
                body: JSON.stringify({
                    username,
                    password,
                }),
            });

            if (response.ok) {
                const data = await response.json();
                if (data.status === 0) {
                    dispatch(login(data));
                    navigate("/");
                    setMsg("");
                } else {
                    setMsg(data.message);
                }
            } else {
                // Handle non-200 response status here
                console.error('Request failed with status:', response.status);
            }
        }
    } catch (error) {
        console.error(error);
    }
};

    return (
        <>
            <Form className="primary-color login-width" onSubmit={handleFormSubmit} style={{ fontWeight: "bold" }}>
                <div className="my-2" style={{ width: "100%" }}>
                    <Form.Group controlId="formUsername">
                        <Form.Label className="login-text">نام کاربری</Form.Label>
                        <Form.Control type="text" name="username" autoComplete="username" />
                    </Form.Group>
                </div>
                <Form.Group controlId="formPassword">
                    <Form.Label className="login-text">رمز عبور</Form.Label>
                    <Form.Control type="password" name="password" autoComplete="current-password" />
                </Form.Group>
                {(msg && !message) && < div className="text-danger mt-3">{msg}</div>}
                {message && <div className="text-danger mt-3">{message}</div>}
                <button type="submit" className="my-5 py-2 text-white w-100 custom-login-button" >
                    ورود به پنل
                </button>
            </Form>
        </>
    );
};

export default FormL;