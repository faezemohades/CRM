export const API_BASE = "https://panel.pishtaz.ir/api/api";
//export const API_BASE = "https://localhost:7232/api";
